package com.rsu.latihanrsu.entity;

import org.springframework.data.annotation.CreatedDate;

import com.rsu.latihanrsu.constant.OutpatientStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@SuperBuilder
@Entity
@Table(name="m_outpatient")
public class Outpatient {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String outpatient_id;

    @CreatedDate
    @Column(name="date_control", nullable=false)
    private String date_control;

    @ManyToOne
    @JoinColumn(name="id_patient", nullable=false)
    private Patient id_patient;

    @ManyToOne
    @JoinColumn(name="id_control_number")
    private ControlNumber id_control_number;

    @ManyToOne
    @JoinColumn(name="id_drug_transaction")
    private DrugTransaction id_drug_transaction;

    @Enumerated(EnumType.STRING)
    @Column(name="status", nullable=false)
    private OutpatientStatus status;
}
