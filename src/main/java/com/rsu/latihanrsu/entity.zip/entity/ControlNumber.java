package com.rsu.latihanrsu.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "control_number")
public class ControlNumber {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String idControlNumber;

    private String controlNumber;

    @ManyToOne
    @JoinColumn(name = "patient_id")
    private Patient patient_id;

    @ManyToOne
    @JoinColumn(name = "doctor_id")
    private Doctor doctor_id;

    @ManyToOne
    @JoinColumn(name = "polyclinic_name")
    private Polyclinic polyclinic_name;

    private Date nextControlDate;
    private String diagnosisDiseases;

    public void setPatientId(String patientId) {
        if (this.patient_id == null) {
            this.patient_id = new Patient();
        }
        this.patient_id.setPatient_id(patientId);
    }

    public void setPolyclinicName(String polyclinicName) {
        Polyclinic polyclinic = new Polyclinic();
        polyclinic.setPolyclinic_name(polyclinicName);
        this.polyclinic_name = polyclinic;
    }

    public String getDoctorId() {
        return this.doctor_id.getDoctor_id();
    }
}