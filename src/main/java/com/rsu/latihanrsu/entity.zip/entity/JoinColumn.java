package com.rsu.latihanrsu.entity;

public @interface JoinColumn {

}
