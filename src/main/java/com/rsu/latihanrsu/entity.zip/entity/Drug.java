package com.rsu.latihanrsu.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Setter
@Getter
@NoArgsConstructor
@ToString
@SuperBuilder
@Entity
@Table(name="t_drug")
public class Drug {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String drug_id;

    @Column(name="drug_name", nullable=false)
    private String drug_name;
    
    @Column(name="drug_price", nullable=false)
    private Long drug_price;

    @Column(name="drug_info")
    private String drug_info;

}
